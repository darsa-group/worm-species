#!/bin/bash
#--------------------------------------------------------------------------#
# Launcher: config-based sweep with shared scratch prepared once
#
# Run from the project root:
#   cd ~/worm-species
#   bash submit_config_sweep_shared_scratch.sh
#
# Behaviour:
#   1. Reads sweep.parameters from config.yaml.
#   2. Generates one run-spec file per sweep combination.
#   3. Creates one shared scratch directory.
#   4. Copies project and data to that scratch directory once.
#   5. Submits independent 1-GPU jobs, at most MAX_ACTIVE active at once.
#   6. Each job reads the shared scratch copy, writes to its own scratch output,
#      and copies its own result back.
#   7. After all jobs finish, launcher removes the shared scratch directory.
#
# Important:
#   This shared-scratch design only works if SCRATCH_ROOT is visible to all
#   nodes where the GPU jobs may run. If /scratch is node-local on your cluster,
#   use the per-job-copy version instead, or constrain all jobs to the same node.
#--------------------------------------------------------------------------#

set -euo pipefail

#--------------------------------------------------------------------------#
# USER SETTINGS
#--------------------------------------------------------------------------#

PROJECT_SRC="${PROJECT_SRC:-$(pwd)}"

# Dataset location on shared filesystem.
DATA_SRC="${DATA_SRC:-/usr/home/qgg/mehrot/worm-species/data}"

BASE_CONFIG="${BASE_CONFIG:-config.yaml}"
TRAIN_SCRIPT="${TRAIN_SCRIPT:-train_multitask_masked.py}"

CONDA_SH="${CONDA_SH:-$HOME/miniconda3/etc/profile.d/conda.sh}"
CONDA_ENV="${CONDA_ENV:-wormspecies}"

# Number of independent 1-GPU jobs allowed to be pending/running at once.
MAX_ACTIVE="${MAX_ACTIVE:-2}"

# Polling interval while waiting for jobs.
POLL_SECONDS="${POLL_SECONDS:-30}"

# Where copied-back outputs and run specs are stored.
RESULTS_ROOT="${RESULTS_ROOT:-${PROJECT_SRC}/outputs_slurm/config_sweep_$(date +%Y%m%d_%H%M%S)}"

# Shared scratch directory. Must be visible to all GPU jobs.
SCRATCH_ROOT="${SCRATCH_ROOT:-/scratch/${USER}/worm_config_sweep_$(date +%Y%m%d_%H%M%S)_$$}"

SCRATCH_PROJECT="${SCRATCH_ROOT}/project"
SCRATCH_DATA="${SCRATCH_ROOT}/data"
SCRATCH_OUTPUTS="${SCRATCH_ROOT}/outputs"

RUN_SPECS_DIR="${RESULTS_ROOT}/run_specs"
SLURM_LOG_DIR="${RESULTS_ROOT}/slurm_logs"

SINGLE_JOB_SCRIPT="${SINGLE_JOB_SCRIPT:-${PROJECT_SRC}/slurm_one_config_sweep_run_shared_scratch.sh}"
SPEC_GENERATOR="${SPEC_GENERATOR:-${PROJECT_SRC}/generate_sweep_run_specs.py}"

# Set to 0 if you want to inspect scratch after completion.
CLEAN_SCRATCH_AT_END="${CLEAN_SCRATCH_AT_END:-1}"

# Optional: add extra sbatch options.
# Example:
#   EXTRA_SBATCH_ARGS="--constraint=a100"
EXTRA_SBATCH_ARGS="${EXTRA_SBATCH_ARGS:-}"

#--------------------------------------------------------------------------#
# Checks
#--------------------------------------------------------------------------#

if [[ ! -d "$PROJECT_SRC" ]]; then
    echo "ERROR: PROJECT_SRC does not exist: $PROJECT_SRC" >&2
    exit 1
fi

if [[ ! -d "$DATA_SRC" ]]; then
    echo "ERROR: DATA_SRC does not exist: $DATA_SRC" >&2
    exit 1
fi

if [[ ! -f "${PROJECT_SRC}/${BASE_CONFIG}" ]]; then
    echo "ERROR: Config not found: ${PROJECT_SRC}/${BASE_CONFIG}" >&2
    exit 1
fi

if [[ ! -f "${PROJECT_SRC}/${TRAIN_SCRIPT}" ]]; then
    echo "ERROR: Training script not found: ${PROJECT_SRC}/${TRAIN_SCRIPT}" >&2
    exit 1
fi

if [[ ! -f "$SINGLE_JOB_SCRIPT" ]]; then
    echo "ERROR: Single-run job script not found: $SINGLE_JOB_SCRIPT" >&2
    exit 1
fi

if [[ ! -f "$SPEC_GENERATOR" ]]; then
    echo "ERROR: Sweep spec generator not found: $SPEC_GENERATOR" >&2
    exit 1
fi

mkdir -p "$RESULTS_ROOT" "$RUN_SPECS_DIR" "$SLURM_LOG_DIR"
mkdir -p "$SCRATCH_PROJECT" "$SCRATCH_DATA" "$SCRATCH_OUTPUTS"

echo "------------------------------------------------------------"
echo "PROJECT_SRC: $PROJECT_SRC"
echo "DATA_SRC: $DATA_SRC"
echo "BASE_CONFIG: $BASE_CONFIG"
echo "TRAIN_SCRIPT: $TRAIN_SCRIPT"
echo "RESULTS_ROOT: $RESULTS_ROOT"
echo "SCRATCH_ROOT: $SCRATCH_ROOT"
echo "MAX_ACTIVE: $MAX_ACTIVE"
echo "CLEAN_SCRATCH_AT_END: $CLEAN_SCRATCH_AT_END"
echo "------------------------------------------------------------"

# Save launcher settings.
cat > "${RESULTS_ROOT}/launcher_settings.txt" <<EOF
PROJECT_SRC=${PROJECT_SRC}
DATA_SRC=${DATA_SRC}
BASE_CONFIG=${BASE_CONFIG}
TRAIN_SCRIPT=${TRAIN_SCRIPT}
RESULTS_ROOT=${RESULTS_ROOT}
SCRATCH_ROOT=${SCRATCH_ROOT}
SCRATCH_PROJECT=${SCRATCH_PROJECT}
SCRATCH_DATA=${SCRATCH_DATA}
SCRATCH_OUTPUTS=${SCRATCH_OUTPUTS}
MAX_ACTIVE=${MAX_ACTIVE}
CONDA_ENV=${CONDA_ENV}
EOF

#--------------------------------------------------------------------------#
# Generate sweep entries from config.yaml
#--------------------------------------------------------------------------#

echo "Generating sweep run specs from ${PROJECT_SRC}/${BASE_CONFIG}..."

N_RUNS=$(
    python "$SPEC_GENERATOR" \
        --config "${PROJECT_SRC}/${BASE_CONFIG}" \
        --out-dir "$RUN_SPECS_DIR"
)

echo "Number of sweep runs: $N_RUNS"
echo "Sweep plan: ${RESULTS_ROOT}/sweep_plan.tsv"

#--------------------------------------------------------------------------#
# Copy project and data to shared scratch once
#--------------------------------------------------------------------------#

echo "Copying project to shared scratch once..."
rsync -a \
    --exclude ".git" \
    --exclude "__pycache__" \
    --exclude ".ipynb_checkpoints" \
    --exclude "outputs" \
    --exclude "outputs_slurm" \
    "${PROJECT_SRC}/" "${SCRATCH_PROJECT}/"

echo "Copying data to shared scratch once..."
rsync -a --info=progress2 "${DATA_SRC}/" "${SCRATCH_DATA}/"

# Marker used by child jobs.
touch "${SCRATCH_ROOT}/READY"

#--------------------------------------------------------------------------#
# Job tracking helpers
#--------------------------------------------------------------------------#

submitted_jobs=()

active_count() {
    local count=0

    for jobid in "${submitted_jobs[@]:-}"; do
        if squeue -h -j "$jobid" | grep -q .; then
            count=$((count + 1))
        fi
    done

    echo "$count"
}

wait_for_slot() {
    while [[ "$(active_count)" -ge "$MAX_ACTIVE" ]]; do
        echo "Currently active jobs: $(active_count). Waiting ${POLL_SECONDS}s..."
        sleep "$POLL_SECONDS"
    done
}

cleanup_scratch() {
    if [[ "$CLEAN_SCRATCH_AT_END" == "1" ]]; then
        echo "Removing shared scratch: $SCRATCH_ROOT"
        rm -rf "$SCRATCH_ROOT"
    else
        echo "Keeping shared scratch for inspection: $SCRATCH_ROOT"
    fi
}

#--------------------------------------------------------------------------#
# Submit independent 1-GPU jobs
#--------------------------------------------------------------------------#

echo "Submitting independent 1-GPU jobs..."

for ((i = 0; i < N_RUNS; i++)); do
    wait_for_slot

    run_name=$(printf "run_%03d" "$i")
    run_spec_file="${RUN_SPECS_DIR}/${run_name}.args"

    if [[ ! -f "$run_spec_file" ]]; then
        echo "ERROR: Missing run spec: $run_spec_file" >&2
        cleanup_scratch
        exit 1
    fi

    echo "Submitting ${run_name}"

    # shellcheck disable=SC2086
    jobid=$(
        sbatch --parsable \
            --job-name="worm_${run_name}" \
            --output="${SLURM_LOG_DIR}/${run_name}_%j.out" \
            --error="${SLURM_LOG_DIR}/${run_name}_%j.err" \
            --export=ALL,RUN_INDEX="$i",RUN_NAME="$run_name",RUN_SPEC_FILE="$run_spec_file",SCRATCH_ROOT="$SCRATCH_ROOT",SCRATCH_PROJECT="$SCRATCH_PROJECT",SCRATCH_DATA="$SCRATCH_DATA",SCRATCH_OUTPUTS="$SCRATCH_OUTPUTS",RESULTS_ROOT="$RESULTS_ROOT",BASE_CONFIG="$BASE_CONFIG",TRAIN_SCRIPT="$TRAIN_SCRIPT",CONDA_SH="$CONDA_SH",CONDA_ENV="$CONDA_ENV" \
            $EXTRA_SBATCH_ARGS \
            "$SINGLE_JOB_SCRIPT"
    )

    submitted_jobs+=("$jobid")
    echo -e "${run_name}\t${jobid}" >> "${RESULTS_ROOT}/submitted_jobs.tsv"
    echo "  job id: ${jobid}"
done

#--------------------------------------------------------------------------#
# Wait for all jobs to finish
#--------------------------------------------------------------------------#

echo "All jobs submitted."
echo "Submitted job IDs: ${submitted_jobs[*]}"
echo "Waiting for all jobs to leave the queue..."

while [[ "$(active_count)" -gt 0 ]]; do
    echo "Active jobs: $(active_count)"
    squeue -h -j "$(IFS=,; echo "${submitted_jobs[*]}")" -o "%.18i %.9P %.32j %.8u %.2t %.10M %.6D %R" || true
    sleep "$POLL_SECONDS"
done

echo "All submitted jobs have left the SLURM queue."

# Final copy-back safeguard in case a child copied back partially.
echo "Final copy-back safeguard from scratch outputs..."
rsync -a "${SCRATCH_OUTPUTS}/" "${RESULTS_ROOT}/scratch_outputs_final_copy/" || true

# Summary.
echo
echo "Run status files:"
find "$RESULTS_ROOT" -name run_status.txt -print -exec cat {} \; || true

cleanup_scratch

echo "Done."
echo "Results: $RESULTS_ROOT"
