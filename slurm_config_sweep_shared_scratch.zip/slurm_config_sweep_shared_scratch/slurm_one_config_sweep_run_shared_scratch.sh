#!/bin/bash
#--------------------------------------------------------------------------#
# One independent 1-GPU job using shared scratch prepared by launcher
#--------------------------------------------------------------------------#

#SBATCH -p ghpc_gpu
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16384
#SBATCH --gres=gpu:1
#SBATCH -t 12:00:00

set -euo pipefail

: "${RUN_INDEX:?RUN_INDEX is required}"
: "${RUN_NAME:?RUN_NAME is required}"
: "${RUN_SPEC_FILE:?RUN_SPEC_FILE is required}"
: "${SCRATCH_ROOT:?SCRATCH_ROOT is required}"
: "${SCRATCH_PROJECT:?SCRATCH_PROJECT is required}"
: "${SCRATCH_DATA:?SCRATCH_DATA is required}"
: "${SCRATCH_OUTPUTS:?SCRATCH_OUTPUTS is required}"
: "${RESULTS_ROOT:?RESULTS_ROOT is required}"
: "${BASE_CONFIG:?BASE_CONFIG is required}"
: "${TRAIN_SCRIPT:?TRAIN_SCRIPT is required}"
: "${CONDA_SH:?CONDA_SH is required}"
: "${CONDA_ENV:?CONDA_ENV is required}"

RUN_SCRATCH_OUT="${SCRATCH_OUTPUTS}/${RUN_NAME}"
RUN_BACK_OUT="${RESULTS_ROOT}/${RUN_NAME}"

mkdir -p "$RUN_SCRATCH_OUT" "$RUN_BACK_OUT"

echo "------------------------------------------------------------"
echo "Run name: $RUN_NAME"
echo "Run index: $RUN_INDEX"
echo "SLURM job ID: $SLURM_JOB_ID"
echo "Node: $(hostname)"
echo "SCRATCH_ROOT: $SCRATCH_ROOT"
echo "SCRATCH_PROJECT: $SCRATCH_PROJECT"
echo "SCRATCH_DATA: $SCRATCH_DATA"
echo "RUN_SCRATCH_OUT: $RUN_SCRATCH_OUT"
echo "RUN_BACK_OUT: $RUN_BACK_OUT"
echo "RUN_SPEC_FILE: $RUN_SPEC_FILE"
echo "------------------------------------------------------------"

if [[ ! -f "${SCRATCH_ROOT}/READY" ]]; then
    echo "ERROR: Shared scratch is not ready: ${SCRATCH_ROOT}/READY missing" >&2
    exit 1
fi

if [[ ! -d "$SCRATCH_PROJECT" ]]; then
    echo "ERROR: SCRATCH_PROJECT missing: $SCRATCH_PROJECT" >&2
    exit 1
fi

if [[ ! -d "$SCRATCH_DATA" ]]; then
    echo "ERROR: SCRATCH_DATA missing: $SCRATCH_DATA" >&2
    exit 1
fi

cp "$RUN_SPEC_FILE" "${RUN_BACK_OUT}/run_overrides.args"

# One override per line.
mapfile -t OVERRIDE_ARGS < "$RUN_SPEC_FILE"

echo "Overrides:"
printf '  %q\n' "${OVERRIDE_ARGS[@]}"

source "$CONDA_SH"
conda activate "$CONDA_ENV"

echo "Python: $(which python)"
echo "Python version: $(python --version)"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "SLURM_JOB_GPUS=${SLURM_JOB_GPUS:-unset}"
echo "SLURM_STEP_GPUS=${SLURM_STEP_GPUS:-unset}"

python - <<'PY'
import os
import torch

print("CUDA_VISIBLE_DEVICES:", os.environ.get("CUDA_VISIBLE_DEVICES"))
print("Torch version:", torch.__version__)
print("Torch CUDA:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
print("GPU count:", torch.cuda.device_count())

if torch.cuda.is_available():
    print("GPU name:", torch.cuda.get_device_name(0))
PY

cd "$SCRATCH_PROJECT"

status=0

srun python "$TRAIN_SCRIPT" \
    --config "$BASE_CONFIG" \
    --override \
        data.root_dir="$SCRATCH_DATA" \
        output.out_dir="$RUN_SCRATCH_OUT" \
        "${OVERRIDE_ARGS[@]}" \
    || status=$?

echo "$status" > "${RUN_SCRATCH_OUT}/run_status.txt"

echo "Copying result back to: $RUN_BACK_OUT"
rsync -a "${RUN_SCRATCH_OUT}/" "${RUN_BACK_OUT}/"

echo "Finished ${RUN_NAME} with status ${status}"
exit "$status"
