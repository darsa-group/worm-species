# Config-based sweep with shared scratch and independent 1-GPU jobs

This version implements the two requested changes:

1. Sweep overrides are generated from `sweep.parameters` in `config.yaml`.
2. Project and data are copied to one shared scratch directory once. Independent 1-GPU jobs reuse that scratch copy. The launcher removes scratch after all jobs finish.

## Files

```text
generate_sweep_run_specs.py
submit_config_sweep_shared_scratch.sh
slurm_one_config_sweep_run_shared_scratch.sh
```

Copy all three files into your project root.

```bash
cp generate_sweep_run_specs.py ~/worm-species/
cp submit_config_sweep_shared_scratch.sh ~/worm-species/
cp slurm_one_config_sweep_run_shared_scratch.sh ~/worm-species/

chmod +x ~/worm-species/generate_sweep_run_specs.py
chmod +x ~/worm-species/submit_config_sweep_shared_scratch.sh
chmod +x ~/worm-species/slurm_one_config_sweep_run_shared_scratch.sh
```

## Expected config format

```yaml
sweep:
  enabled: true
  parameters:
    model.name:
      - efficientnet_b0
      - resnet18
    data.image_col:
      - rel_path_seg
      - rel_path_raw
    training.lr:
      - 0.0001
      - 0.00005
```

The launcher will generate all Cartesian-product combinations.

## Run

```bash
cd ~/worm-species
bash submit_config_sweep_shared_scratch.sh
```

Useful environment overrides:

```bash
DATA_SRC=/usr/home/qgg/mehrot/worm-species/data \
MAX_ACTIVE=2 \
CONDA_ENV=wormspecies \
bash submit_config_sweep_shared_scratch.sh
```

## Important HPC caveat

This design assumes the scratch path is visible to all GPU jobs.

If `/scratch` is node-local, independent jobs on different nodes will not see the shared scratch directory. In that case, either:

1. use the earlier per-job-copy script;
2. use a single multi-GPU allocation and run multiple `srun`s inside it;
3. constrain all jobs to the same node if your cluster allows this;
4. use a genuinely shared high-performance filesystem instead of node-local `/scratch`.

## Outputs

The launcher creates:

```text
outputs_slurm/config_sweep_YYYYMMDD_HHMMSS/
├── launcher_settings.txt
├── sweep_plan.tsv
├── submitted_jobs.tsv
├── run_specs/
├── slurm_logs/
├── run_000/
├── run_001/
└── scratch_outputs_final_copy/
```
